import React, { useState } from 'react';
import { StyleSheet, Text, View, Button, Alert, Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import axios from 'axios';

const NewMc1 = () => {
    const [fileUri, setFileUri] = useState(null);
    const [startDate, setStartDate] = useState(new Date());
    const [endDate, setEndDate] = useState(new Date());
    const [showStartDatePicker, setShowStartDatePicker] = useState(false);
    const [showEndDatePicker, setShowEndDatePicker] = useState(false);

    const pickFile = async () => {
        try {
            let result = await ImagePicker.launchImageLibraryAsync({
                mediaTypes: ImagePicker.MediaTypeOptions.All,
                allowsEditing: true,
                aspect: [4, 3],
                quality: 1,
            });

            if (!result.cancelled) {
                setFileUri(result.uri);
            }
        } catch (error) {
            console.error('Error picking file:', error);
            Alert.alert('Error', 'Failed to pick file.');
        }
    };

    const handleFileUpload = async () => {
        try {
            if (!fileUri) {
                Alert.alert('Error', 'Please select a file.');
                return;
            }

            const formData = new FormData();
            formData.append('file', {
                uri: fileUri,
                name: 'file',
                type: 'image/jpeg',
            });

            const uploadResponse = await axios.post('https://api.pdp.university/api/attachment/v1/attachment/upload-lms-files', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            return uploadResponse.data.data[0].url; // Return the URL of the uploaded file
        } catch (error) {
            console.error('Error uploading file:', error);
            Alert.alert('Error', 'Failed to upload file.');
        }
    };

    const submitMitigatingCircumstance = async () => {
        try {
            const uploadedFileUrl = await handleFileUpload();

            if (!uploadedFileUrl) {
                return; // Stop further processing if file upload fails
            }

            const mcPayload = {
                description: "Description of mitigating circumstance...",
                startDate: startDate.getTime(),
                endDate: endDate.getTime(),
                files: [uploadedFileUrl]
            };

            const submitResponse = await axios.post('https://api.pdp.university/api/university/v2/mitigating-circumstance/apply', mcPayload);

            if (submitResponse.data.success) {
                Alert.alert('Success', 'MITIGATING_CIRCUMSTANCE_SUCCESSFULLY_SAVED');
            } else {
                Alert.alert('Error', 'Failed to save mitigating circumstance.');
            }
        } catch (error) {
            console.error('Error:', error);
            Alert.alert('Error', 'Failed to upload file and submit mitigating circumstance.');
        }
    };

    const handleStartDateChange = (event, selectedDate) => {
        const currentDate = selectedDate || startDate;
        setShowStartDatePicker(Platform.OS === 'ios');
        setStartDate(currentDate);
    };

    const handleEndDateChange = (event, selectedDate) => {
        const currentDate = selectedDate || endDate;
        setShowEndDatePicker(Platform.OS === 'ios');
        setEndDate(currentDate);
    };

    return (
        <View style={styles.container}>
            <Button title="Select File from Gallery" onPress={pickFile} />
            {fileUri && <Text>File selected: {fileUri}</Text>}
            <Button title="Select Start Date" onPress={() => setShowStartDatePicker(true)} />
            {showStartDatePicker && (
                <DateTimePicker
                    testID="startDatePicker"
                    value={startDate}
                    mode="date"
                    is24Hour={true}
                    display="default"
                    onChange={handleStartDateChange}
                />
            )}
            <Button title="Select End Date" onPress={() => setShowEndDatePicker(true)} />
            {showEndDatePicker && (
                <DateTimePicker
                    testID="endDatePicker"
                    value={endDate}
                    mode="date"
                    is24Hour={true}
                    display="default"
                    onChange={handleEndDateChange}
                />
            )}
            <Button title="Submit" onPress={submitMitigatingCircumstance} />
        </View>
    );
};

export default NewMc1;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        padding: 20
    }
});
