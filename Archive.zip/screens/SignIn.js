import { StyleSheet, Text, TextInput, TouchableOpacity, View, KeyboardAvoidingView, Image, Platform } from 'react-native'
import React, { useContext, useState } from 'react'
import axios from "axios";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AuthContext } from '../navigations/Navigation';
import { Ionicons } from '@expo/vector-icons';
const SignIn = () => {
    const [phoneNumber, setPhoneNumber] = useState('');
    const [password, setPassword] = useState('');
    const [otp, setOtp] = useState('');
    const [isSuccess, setSuccess] = useState(false);
    const [smsId, setSmsId] = useState('');
    const [device, setDevice] = useState(false);
    const [err, setError] = useState('');
    const [autoFilledOTP, setAutoFilledOTP] = useState('');

    const nv = () =>{
        setSuccess(false)
    }

    const { activate } = useContext(AuthContext);

    const phoneWithoutSpaces = phoneNumber.replace(/\s/g, '');
    const formattedPhoneNumber = '+998' + phoneWithoutSpaces;

    function sign_in() {
        const options = {
            method: 'POST',
            url: 'https://api.pdp.university/api/auth/v1/auth/university-sign-in',
            headers: {
                'Content-Type': 'application/json',
            },
            data: { password: password, phoneNumber: formattedPhoneNumber,  }
        };

        axios.request(options).then(function (response) {
            console.log('sms id: ', response.data.data.smsCode.smsCodeId);
            if (response.data.success) {
                setSuccess(true)
                setError('')
                setSmsId(response.data.data.smsCode.smsCodeId)
                setDevice(true)
            }
            console.log(response.data);
        }).catch(function (error) {
            setError('Incorrect Number or Password')
            // console.error(error);
        });
    }

    function otp_check() {
        const options = {
            method: 'POST',
            url: 'https://api.pdp.university/api/auth/v1/auth/university-check-code',
            headers: {
                'Content-Type': 'application/json',
            },
            data: {
                phoneNumber: formattedPhoneNumber,
                password: password,
                smsCode: otp,
                smsCodeId: smsId,
                reliableDevice: device,
                verificationType: 'PHONE_NUMBER'
            }
        };

        axios.request(options).then(function (response) {
            if (response.data.success) {
                setError('')
                setItemToAsyncStorage(response.data.data.token.accessToken, response.data.data.token.refreshToken);
            }
            console.log(response.data);
        }).catch(function (error) {
            setError('Incorrect Verification code')
            // console.error(error);
        });
    }

    

    const setItemToAsyncStorage = async (e1, e2) => {
        try {
            await AsyncStorage.setItem('token', JSON.stringify(e1));
            await AsyncStorage.setItem('refresh', JSON.stringify(e2));

            console.log("token: ", e1);
            console.log("refresh: ", e2);
            console.log('Item set in AsyncStorage');
            activate()
        } catch (error) {
            console.error(error);
        }
    };

    const formatPhoneNumber = (input) => {
        const cleaned = ('' + input).replace(/\D/g, '');
        const match = cleaned.match(/^(\d{0,2})(\d{0,3})(\d{0,2})(\d{0,2})$/);
        if (match) {
            return match.slice(1).filter(Boolean).join(' ');
        }
        return '';
    };


    return (
        <KeyboardAvoidingView style={styles.contsiner}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
            <Image
                source={require('../assets/bigLOGO.png')}
                style={{ width: 250, height: 150 }}
            />
            <View style={styles.cardWrapper}>
                {!isSuccess ? (
                    <>
                        <View style={{ width: '95%' }}>
                            <Text style={styles.labelText}>Log in: </Text>

                        </View>
                        <View style={styles.inputWrp}>
                            <View style={styles.flagWrp}>
                                <Image style={{ width: '100%', height: '100%' }} source={require('../assets/uzbekistan.png')} />
                            </View>
                            <Text style={styles.inputText}> +998 </Text>
                            <TextInput
                                style={[styles.inputPhone, styles.inputText]}
                                placeholder="-- --- -- --"
                                value={formatPhoneNumber(phoneNumber)}
                                onChangeText={(text) => {
                                    const formattedPhoneNumber = formatPhoneNumber(text.replace(/\D/g, ''));
                                    setPhoneNumber(formattedPhoneNumber);
                                }}
                                keyboardType="phone-pad"
                            />
                        </View>

                        <TextInput
                            style={styles.input}
                            placeholder='Password'
                            value={password}
                            onChangeText={(e) => setPassword(e)}
                            secureTextEntry
                        />

                        {/* <Button title='Sign in' onPress={sign_in} /> */}
                        {err && <Text style={styles.error}>{err}</Text>}
                        <TouchableOpacity
                            onPress={sign_in}
                            style={styles.btn}
                        >
                            <Text
                                style={styles.text}
                            >
                                Sign in
                            </Text>
                        </TouchableOpacity>

                    </>
                ) : (
                    <>
                        <View style={{ width: '95%' }}>
                            <Text style={styles.labelText}>Verification code: </Text>
                        </View>
                        <TextInput
                            style={[styles.input, { textAlign: 'center' }]}
                            placeholder='- - - - - -'
                            value={otp}
                            onChangeText={(e) => setOtp(e)}
                            keyboardType="phone-pad"
                        />
                        {err && <Text style={styles.error}>{err}</Text>}
                        <View style={{ width: '100%', alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 10 }}>
                            <TouchableOpacity style={[styles.btn, {width: '17%', backgroundColor: '#fff'}]} onPress={()=>nv()}>
                            <Ionicons name="arrow-back" size={24} color="#27A49E" />
                            </TouchableOpacity>
                            <TouchableOpacity
                                onPress={otp_check}
                                style={[styles.btn, {width: '80%'}]}
                            >
                                <Text
                                    style={styles.text}
                                >
                                    Send
                                </Text>
                            </TouchableOpacity>
                        </View>
                    </>
                )}
            </View>
        </KeyboardAvoidingView >
    )
}



export default SignIn

const styles = StyleSheet.create({
    contsiner: {
        flex: 1,
        alignItems: 'center',
        backgroundColor: '#F0F2F4',
        paddingTop: '40%'
    },
    cardWrapper: {
        width: '90%',
        backgroundColor: '#fff',
        paddingHorizontal: 10,
        paddingVertical: 20,
        borderRadius: 20,
        borderColor: '#D8D8D8',
        borderWidth: 1,
        alignItems: 'center',
    },
    input: {
        width: '95%',
        height: 40,
        backgroundColor: '#F0F2F4',
        marginBottom: 10,
        borderRadius: 10,
        fontSize: 18,
        fontWeight: 'bold',
        paddingHorizontal: 20,
        color: '#363944',
        borderColor: '#D8D8D8',
        borderWidth: 1,
        borderRadius: 5,
        // backgroundColor: 'yellow'
    },
    btn: {
        width: '95%',
        height: 40,
        alignItems: 'center',
        justifyContent: 'center',
        borderColor: '#D8D8D8',
        borderWidth: 1,
        borderRadius: 5,
        backgroundColor: '#018882',
    },
    text: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#fff'
    },
    labelText: {
        fontSize: 22,
        fontWeight: 'bold',
        marginBottom: 10,
        color: '#018882',
    },
    inputWrp: {
        width: '95%',
        marginBottom: 10,
        height: 40,
        borderColor: '#D8D8D8',
        borderWidth: 1,
        borderRadius: 5,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 10,
        backgroundColor: '#F0F2F4'
    },
    inputPhone: {
        // flex: 1,
        // height: 40,
        // borderRadius: 5,
        height: '100%',
        // backgroundColor: 'yellow',
        width: '65%'
    },
    flagWrp: {
        width: 30,
        height: 20,
    },
    inputText: {
        fontWeight: 'bold',
        fontSize: 22,
        color: '#363944',
        // backgroundColor: 'yellow'
    },
    error: {
        marginBottom: 8,
        color: 'red',
    },
})