import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, RefreshControl, Platform, TouchableOpacity, ActivityIndicator } from 'react-native';
import api from '../api';
import { useNavigation } from '@react-navigation/native';
import AnimatedLoader from 'react-native-animated-loader';

const Attendance = () => {
  const navigation = useNavigation(); // Move this hook outside of the component body

  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedSemester, setSelectedSemester] = useState("SEMESTER_2");

  useEffect(() => {
    getData();
  }, [selectedSemester]);

  const getData = () => {
    const payload = {
      currentHorizontal: "SEMESTER",
      currentVertical: "MODULE",
      filter: { ACADEMIC_YEAR: "YEAR_2023_24" },
      horizontalItems: ["SEMESTER", "ACADEMIC_YEAR", "MONTH", "DAY"],
      onlyBootcamp: false,
      onlyGrantee: false,
      verticalItems: ["MODULE", "GROUP", "MENTOR"]
    };

    api
      .post("university/v2/dashboard/admin/attendance", payload)
      .then((res) => {
        setData(res.data.data);
        console.log("----------------");
        console.log("----------------");
        console.log(res.data.data);
        console.log("----------------");
        console.log("----------------");
        setLoading(false);
        setRefreshing(false);
      })
      .catch((error) => {
        console.error('Error fetching data: ', error);
        setLoading(false);
        setRefreshing(false);
      });
  };


  const onRefresh = () => {
    setRefreshing(true);
    // Clear existing data
    setData([]);
    // Set loading to true to show loading indicator
    // setLoading(true);
    // Fetch new data after a brief delay
    setTimeout(() => {
      getData();
      // Set refreshing to false after fetching data
      setRefreshing(false);
    }, 1000); // Adjust the delay as needed
  };



  const handleSemesterChange = (semester) => {
    setSelectedSemester(semester);
  };



  const calculateAttendancePercentage = (semesterData) => {
    if (!semesterData) return 0;

    const { ALL, EXCUSED, PRESENT, LATE } = semesterData;

    // Calculate total satisfactory days, considering half weight for late arrivals
    const totalSatisfactoryDays = EXCUSED + PRESENT + Math.ceil(LATE / 2);

    // Calculate the percentage of total days attended
    const percentage = (totalSatisfactoryDays / ALL) * 100;

    // Return the calculated percentage, ensuring it doesn't exceed 100%
    return Math.min(Math.round(percentage), 100);
  };





  const getBackgroundColor = (percentage) => {
    if (percentage >= 80) {
      return "#00B332";
    } else if (percentage >= 75) {
      return "#52C572";
    } else if (percentage >= 65) {
      return "#FFCC1B";
    } else {
      return "#FF623F";
    }
  };

  // Filter out subjects not available in the selected semester
  const filteredData = data.filter(item => item[selectedSemester],);
  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <AnimatedLoader
          visible={true}
          overlayColor="rgba(255,255,255)"
          source={require("../assets/mine.json")}
          animationStyle={{ width: 400, height: 400 }}
          speed={1}
        >
          {/* <Text style={{fontWeight: 'bold', color: '#27A49E'}}>Loading...</Text> */}
        </AnimatedLoader>
      </View>
    );
  }

  const handleCardTap = (subject) => {
    navigation.navigate('AttendanceModule', { subject, SEMESTER: selectedSemester, getBackgroundColor });
  };

  return (
    <View style={{ alignItems: 'center', justifyContent: 'center' }}>
      <View style={styles.header}>
        <Text style={{
          ...Platform.select({
            ios: {
              fontSize: 20
            },
            android: {
              fontSize: 16
            },
            default: {
              fontSize: 20, // fallback for other platforms
            }
          }), fontWeight: 'bold', color: '#27A49E'
        }}>Semester:</Text>
        <View style={styles.selectorContainer}>
          <TouchableOpacity
            style={[styles.semesterButton, selectedSemester === 'SEMESTER_1' && styles.selectedButton]}
            onPress={() => handleSemesterChange('SEMESTER_1')}
          >
            <Text style={[styles.buttonText, selectedSemester === 'SEMESTER_1' && styles.selestedButtonText]}>1</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.semesterButton, selectedSemester === 'SEMESTER_2' && styles.selectedButton]}
            onPress={() => handleSemesterChange('SEMESTER_2')}
          >
            <Text style={[styles.buttonText, selectedSemester === 'SEMESTER_2' && styles.selestedButtonText]}>2</Text>
          </TouchableOpacity>
        </View>
      </View>
      <ScrollView
        style={{ width: '100%', height: '100%', marginBottom: 70 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={["#27A49E"]}
            tintColor="#27A49E"
          />
        }
      >

        <View style={{ width: '100%', alignItems: 'center' }}>
          {filteredData.map((item, index) => (
            <TouchableOpacity key={index} style={styles.cardWrapper} onPress={() => handleCardTap(item.vertical)}>
              <View style={[styles.colorIndicator, { backgroundColor: getBackgroundColor(calculateAttendancePercentage(item[selectedSemester])) }]}></View>
              <Text style={styles.subjectName}>{item.vertical}  </Text>
              <View style={[styles.percentageBox, { backgroundColor: getBackgroundColor(calculateAttendancePercentage(item[selectedSemester])) }]}>
                <Text style={styles.percentageTextColor}>
                  {calculateAttendancePercentage(item[selectedSemester])}%
                </Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
        
      </ScrollView>
    </View>
  );
};

export default Attendance;

const styles = StyleSheet.create({
  header: {
    width: '95%',
    height: 50,
    paddingHorizontal: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#D8D8D8',
    borderRadius: 10,
    marginTop: 10
  },
  selectorContainer: {
    flexDirection: 'row',
  },
  semesterButton: {

    ...Platform.select({
      ios: {
        paddingVertical: 8,
      },
      android: {
        paddingVertical: 4,
      },
      default: {
        paddingVertical: 8, // fallback for other platforms
      }
    }),
    paddingHorizontal: 20,
    borderRadius: 5,
    marginLeft: 10,
    borderWidth: 1,
    borderColor: '#27A49E',
    backgroundColor: '#fff',
    borderColor: '#D8D8D8',
    borderWidth: 1,
  },
  selectedButton: {
    backgroundColor: '#27A49E'
  },
  buttonText: {
    color: '#27A49E',
    fontWeight: 'bold',
    ...Platform.select({
      ios: {
        fontSize: 16
      },
      android: {
        fontSize: 12
      },
      default: {
        fontSize: 16, // fallback for other platforms
      }
    }),
  },
  selestedButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  cardWrapper: {
    width: '95%',
    ...Platform.select({
      ios: {
        height: 80,
      },
      android: {
        height: 70,
      },
      default: {
        height: 80,// fallback for other platforms
      }
    }),
    backgroundColor: '#fff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    borderRadius: 15,
    borderColor: '#D8D8D8',
    borderWidth: 1,
    justifyContent: 'space-between',
    marginTop: 10,
  },
  colorIndicator: {
    width: 10,
    ...Platform.select({
      ios: {
        height: 64,
      },
      android: {
        height: 50,
      },
      default: {
        height: 64,// fallback for other platforms
      }
    }),
    marginRight: 10,
    borderRadius: 3,
  },
  percentageBox: {
    ...Platform.select({
      ios: {
        height: 64,
        width: 64,
      },
      android: {
        height: 50,
        width: 50,
      },
      default: {
        width: 64,
        height: 64,// fallback for other platforms
      }
    }),
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  percentageTextColor: {
    color: '#fff',
    ...Platform.select({
      ios: {
        fontSize: 16
      },
      android: {
        fontSize: 12
      },
      default: {
        fontSize: 16, // fallback for other platforms
      }
    }),
    fontWeight: 'bold',
  },
  subjectName: {
    ...Platform.select({
      ios: {
        fontSize: 16
      },
      android: {
        fontSize: 12
      },
      default: {
        fontSize: 16, // fallback for other platforms
      }
    }),
    flexWrap: 'wrap',
    width: '70%',
    fontWeight: 'bold',
    color: '#002930',
    marginRight: 5
  },
  
});
