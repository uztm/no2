import { StyleSheet, View, ScrollView, RefreshControl, Text } from 'react-native';
import React, { useState } from 'react';
import StudentId from '../src/components/StudentId';
import StudentData from '../src/components/StudentData';
import AttendanceComponent from '../src/components/AttendanceComponent';
import TodaysLessons from '../src/components/TodaysLessons';

const Home = () => {
    const [refreshing, setRefreshing] = useState(false);

    const onRefresh = () => {
        setRefreshing(true);
        // Call the refresh function in each child component
        setRefreshing(false);
    };

    return (
        <ScrollView
            contentContainerStyle={styles.scrollView}
            refreshControl={
                <RefreshControl
                    refreshing={refreshing}
                    onRefresh={onRefresh}
                />
            }
        >
            <StudentId refreshing={refreshing} />
            <StudentData refreshing={refreshing} />
            <TodaysLessons />
            <AttendanceComponent />
        </ScrollView>

    );
};

export default Home;

const styles = StyleSheet.create({
    scrollView: {
        flexGrow: 1,
        alignItems: 'center',
        marginTop: 10,
        paddingBottom: 10,
        paddingHorizontal: 5
    }
});
