import { StyleSheet, Text, View, TouchableOpacity, Alert } from 'react-native'
import React from 'react'
import { MaterialIcons, AntDesign, Feather } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const More = ({ route }) => {
    const { logout } = route.params;
    const navigation = useNavigation();

    const handleLogout = () => {
        Alert.alert(
            "Confirm Logout",
            "Are you sure you want to log out?",
            [
                {
                    text: "Cancel",
                    onPress: () => console.log("Cancel Pressed"),
                    style: "cancel"
                },
                { text: "Logout", onPress: logout }
            ],
            { cancelable: false }
        );
    };

    const navGrade = () => {
        navigation.navigate('grade')
    }
    const navMc = () => {
        navigation.navigate('mc')
    }
    const Survey = () => {
        navigation.navigate('Survey')
    }

    
    const Assignments = () => {
        navigation.navigate('Assignments')
    }



    return (
        <View style={styles.container}>
            <View style={styles.body}>
                <TouchableOpacity style={styles.gradeBoxContainer} onPress={navGrade}>
                    <View style={styles.gradeBox}>
                        <Text style={styles.title}>My grades</Text>
                        <AntDesign name="staro" size={28} color="#018882" />
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style={styles.gradeBoxContainer} onPress={Assignments}>
                    <View style={styles.gradeBox}>
                        <Text style={styles.title}>Student Assignments</Text>
                        <Feather name="clipboard" size={28} color="#018882" />
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style={styles.gradeBoxContainer} onPress={navMc}>
                    <View style={styles.gradeBox}>
                        <Text style={styles.title}>Student's MC</Text>
                        <AntDesign name="paperclip" size={28} color="#018882" />
                    </View>
                </TouchableOpacity>
                
                {/* <TouchableOpacity style={styles.gradeBoxContainer} onPress={Survey}>
                    <View style={styles.gradeBox}>
                        <Text style={styles.title}>Students Survey</Text>
                        <AntDesign name="checksquareo" size={28} color="#018882" />
                    </View>
                </TouchableOpacity> */}

            </View>
            <TouchableOpacity style={styles.logOut} onPress={handleLogout}>
                <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#fff' }}>Log out</Text>
                <MaterialIcons name="logout" size={22} color="#fff" style={{ marginLeft: 10 }} />
            </TouchableOpacity>
        </View>
    )
}

export default More

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 10,
    },
    logOut: {
        width: '100%',
        height: 40,
        backgroundColor: '#018882',
        alignItems: 'center',
        justifyContent: 'center',
        borderColor: '#D8D8D8',
        borderWidth: 1,
        borderRadius: 10,
        flexDirection: 'row',
    },
    gradeBoxContainer: {
        width: '100%',
        marginBottom: 10
    },
    gradeBox: {
        width: '100%',
        paddingVertical: 10,
        borderColor: '#D8D8D8',
        borderWidth: 1,
        backgroundColor: '#fff',
        borderRadius: 15,
        alignItems: 'center',
        justifyContent: 'space-between',
        flexDirection: 'row',
        paddingHorizontal: 15
    },
    title: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#002930',
    },
})
