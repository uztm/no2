import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, Platform, PanResponder, RefreshControl, TouchableOpacity } from 'react-native';
import api from '../api';
import AnimatedLoader from 'react-native-animated-loader';
import { AntDesign } from '@expo/vector-icons'; // Import reload icon from Expo icons

const Calendar = () => {
    const [lessons, setLessons] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [refreshing, setRefreshing] = useState(false);
    const scrollViewRef = useRef(null);

    useEffect(() => {
        fetchDataForWeek();
    }, []);

    useEffect(() => {
        const panResponder = PanResponder.create({
            onStartShouldSetPanResponder: () => true,
            onPanResponderRelease: (_, gestureState) => {
                if (gestureState.dy > 50) { // Detect if swipe down is greater than 50 pixels
                    handleSwipeRefresh();
                }
            }
        });

        const scrollView = scrollViewRef.current;
        if (scrollView) {
            scrollView.setNativeProps({ // Assign panResponder to ScrollView
                panResponder: panResponder.panHandlers,
            });
        }

        return () => {
            if (scrollView) {
                scrollView.setNativeProps({ panResponder: null }); // Remove panResponder on unmount
            }
        };
    }, []);

    const handleSwipeRefresh = () => {
        setRefreshing(true);
        fetchDataForWeek();
    };

    const fetchDataForWeek = async () => {
        const dates = ['2024-03-25', '2024-03-26', '2024-03-27', '2024-03-28', '2024-03-29']; // Dates for Monday to Friday
        const lessonsData = {};

        try {
            for (const date of dates) {
                const response = await api.get(`university/v2/student/lessons-by-date/${date}`);
                lessonsData[date] = response.data.data || [];
            }
            setLessons(lessonsData);
        } catch (error) {
            setError(error.message);
        } finally {
            setRefreshing(false); // Set refreshing to false after data fetching is complete
            setLoading(false);
        }
    };

    const handleReload = () => {
        setLoading(true);
        setError(null);
        fetchDataForWeek();
    };

    if (loading) {
        return (
            <View style={styles.container}>
                <AnimatedLoader
                    visible={true}
                    overlayColor="rgba(255,255,255)"
                    source={require("../assets/mine.json")}
                    animationStyle={{width: 400, height: 400}}
                    speed={1}
                >
                    {/* <Text style={{fontWeight: 'bold', color: '#27A49E'}}>Loading...</Text> */}
                </AnimatedLoader>
            </View>
        );
    }

    if (error) {
        return (
            <View style={styles.container}>
                <Text style={{fontSize: 18, fontWeight: 'bold', marginBottom: 10}}>Error: {error}</Text>
                <TouchableOpacity onPress={handleReload} style={{width: 150, height: 40, backgroundColor: '#10857C', alignItems: 'center', justifyContent: 'center', borderRadius: 20}}>
                    <AntDesign name="reload1" size={24} color="#fff" />
                </TouchableOpacity>
            </View>
        );
    }

    const renderCard = (day, lessons) => {
        const lessonContainers = Array.from({ length: 3 }, (_, index) => {
            const lesson = lessons[index];
            if (lesson) {
                return (
                    <View key={`${day}-${index}`} style={styles.lessonContainer}>
                        <Text style={styles.lessonText}>Module: {lesson.modulName}</Text>
                        {/* <View style={styles.line}></View> */}
                        <Text style={styles.mentorText}>Mentor: {lesson.mentor.fullName}</Text>
                    </View>
                );
            } else {
                return (
                    <View key={`${day}-${index}`} style={[styles.lessonContainer, { backgroundColor: '#F0F2F4', alignItems: 'center' }]}>
                        {/* <Text>- - -</Text> */}
                    </View>
                );
            }
        });

        return (
            <View key={day} style={styles.card}>
                <View style={styles.header}>
                    <Text style={styles.heading}>{day}:</Text>
                </View>
                {lessonContainers}
            </View>
        );
    };


    return (
        <View style={styles.container}>
            <ScrollView
                ref={scrollViewRef}
                style={{ width: '100%' }}
                refreshControl={
                    <RefreshControl refreshing={refreshing} onRefresh={handleSwipeRefresh} />
                }
            >
                {Object.entries(lessons).map(([date, lessonsData]) => (
                    renderCard(getDayOfWeek(date), lessonsData)
                ))}
            </ScrollView>
        </View>
    );
};

const getDayOfWeek = (dateString) => {
    const date = new Date(dateString);
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[date.getDay()];
}

export default Calendar;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        padding: 10
    },
    card: {
        backgroundColor: '#fff',
        borderRadius: 15,
        borderColor: '#D8D8D8',
        borderWidth: 1,
        width: '100%',
        overflow: 'hidden',
        marginBottom: 15,
    },
    header: {
        width: '100%',
        backgroundColor: '#018882',
        borderStartEndRadius: 15,
        borderStartStartRadius: 15,
        paddingHorizontal: 15,
        alignItems: 'start',
        justifyContent: 'center',
        paddingVertical: 10,
        marginBottom: 10
    },
    heading: {
        ...Platform.select({
            ios: {
              fontSize: 18,
            },
            android: {
              fontSize: 14,
            },
            default: {
              fontSize: 16, // fallback for other platforms
            }
          }),
        fontWeight: 'bold',
        color: '#fff'
    },
    lessonContainer: {
        marginBottom: 10,
        backgroundColor: '#F0F2F4',
        padding: 10,
        borderRadius: 10,
        marginHorizontal: 10,
        minHeight: 40,
        alignItems: 'start',
        justifyContent: 'center'
    },
    lessonText: {

        color: '#002930',
        fontWeight: 'bold',
        ...Platform.select({
            ios: {
              fontSize: 16,
            },
            android: {
              fontSize: 14,
            },
            default: {
              fontSize: 16, // fallback for other platforms
            }
          })
    },
    mentorText: {
        fontSize: 12,
        color: '#002930',
        fontWeight: '500',
        marginTop: 10
    },
    line: {
        width: '100%',
        height: .3,
        backgroundColor: '#002930',
        marginVertical: 5,
    },
});
