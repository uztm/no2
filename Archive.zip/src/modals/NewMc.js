import React, { useState, useEffect } from 'react';
import { Button, View, Text, Platform, TouchableOpacity, StyleSheet, TextInput, Image, ActivityIndicator } from 'react-native'; // Import Image from react-native
import * as ImagePicker from 'expo-image-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Feather, MaterialIcons } from '@expo/vector-icons';

export default function NewMc({ navigation }) {
    const [images, setImages] = useState([]);
    const [imageIds, setImageIds] = useState([]);
    const [startDate, setStartDate] = useState(new Date());
    const [endDate, setEndDate] = useState(new Date());
    const [comment, setComment] = useState('');
    const [imageShow, setImageShow] = useState(null); // Set initial state to null
    const [isUploading, setIsUploading] = useState(false)
    useEffect(() => {
        (async () => {
            if (Platform.OS !== 'web') {
                const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
                if (status !== 'granted') {
                    alert('Sorry, we need camera roll permissions to make this work!');
                }
            }
        })();
    }, []);
    const [isBtnFileDisabled, setIsBtnFileDisabled] = useState(false);


    const pickImage = async () => {
        let result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.All,
            quality: 0,
        });

        if (!result.cancelled) {
            setImages([...images, ...result.assets]);
            setImageShow(result.assets[0].uri)
            result.assets.forEach(image => {
                uploadImage(image.uri);
            });
        }

        if (images.length + result.assets.length > 3 || result.assets.some(image => image.fileName.length > 3)) {
            setIsBtnFileDisabled(true);
        }
    };

    const uploadImage = async (uri) => {
        try {
            const formData = new FormData();
            formData.append('file', {
                uri,
                name: 'image.jpg',
                type: 'image/jpeg',
            });

            // Set loading state to true while uploading
            setIsUploading(true);

            const response = await fetch('https://api.pdp.university/api/attachment/v1/attachment/upload-lms-files', {
                method: 'POST',
                body: formData,
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            const data = await response.json();
            if (data.success) {
                setImageIds([...imageIds, data.data[0].id]);
            } else {
                console.error("Upload failed:", data.message);
            }
        } catch (error) {
            console.error("Upload error:", error);
        } finally {
            // Reset loading state to false after upload completes
            setIsUploading(false);
        }
    };


    const handleApply = async () => {
        const payload = {
            startDate: startDate.getTime(),
            endDate: endDate.getTime(),
            description: comment,
            files: imageIds,
        };

        try {
            let response = await fetch('https://api.pdp.university/api/university/v2/mitigating-circumstance/apply', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });

            let data = await response.json();
            if (data.success) {
                navigation.goBack()
            } else {
                console.error(data.message);
            }
        } catch (error) {
            console.error(error);
        }
    };


    const handleStartDateChange = (event, selectedDate) => {
        const currentDate = selectedDate || startDate;
        setShowStartDatePicker(Platform.OS === 'ios');
        setStartDate(currentDate);
    };

    const handleEndDateChange = (event, selectedDate) => {
        const currentDate = selectedDate || endDate;
        setShowEndDatePicker(Platform.OS === 'ios');
        setEndDate(currentDate);
    };

    const toggleStartTimePicker = () => {
        setShowStartDatePicker(!showStartDatePicker);
    };
    const toggleEndTimePicker = () => {
        setShowEndDatePicker(!showEndDatePicker);
    };
    const [showStartDatePicker, setShowStartDatePicker] = useState(false);
    const [showEndDatePicker, setShowEndDatePicker] = useState(false);

    const deleteImage = (index) => {
        // const newImages = [...images];
        // newImages.splice(index, 1);
        // setImages(newImages);

        // // Enable btnFile if less than or equal to 2 images and each image's fileName length is less than or equal to 2
        // if (newImages.length <= 2 && newImages.every(image => image.fileName.length <= 2)) {
        //     setIsBtnFileDisabled(false);
        // }
        setImages([])
        setImageIds([])
        setIsBtnFileDisabled(false)

    };

    return (
        <View style={styles.container}>
            <View style={styles.form}>


                <TouchableOpacity style={styles.wrp} onPress={toggleStartTimePicker}>
                    <Text style={styles.label}>Start Time:</Text>
                    <View style={styles.datePicker}>
                        <Feather name="calendar" size={22} color="#018882" />
                        <Text style={{ color: '#018882', fontWeight: 'bold' }}>{startDate.toLocaleDateString()}</Text>
                    </View>
                </TouchableOpacity>
                {showStartDatePicker && (
                    <DateTimePicker
                        testID="startDatePicker"
                        value={startDate}
                        mode="date"
                        is24Hour={true}
                        display="default"
                        onChange={handleStartDateChange}
                        style={{ marginBottom: 10 }}
                    />
                )}
                <TouchableOpacity style={styles.wrp} onPress={toggleEndTimePicker}>
                    <Text style={styles.label}>End Time:</Text>
                    <View style={styles.datePicker}>
                        <Feather name="calendar" size={22} color="#018882" />
                        <Text style={{ color: '#018882', fontWeight: 'bold' }}>{endDate.toLocaleDateString()}</Text>
                    </View>
                </TouchableOpacity>
                {showEndDatePicker && (
                    <DateTimePicker
                        testID="endDatePicker"
                        value={endDate}
                        mode="date"
                        is24Hour={true}
                        display="default"
                        onChange={handleEndDateChange}
                        style={{ marginBottom: 10 }}
                    />
                )}


                <TextInput
                    value={comment}
                    onChangeText={(e) => setComment(e)}
                    placeholder='Comment'
                    style={[styles.input]}
                />
                <View style={styles.uploadWrapper}>
                    <View style={{ alignItems: 'center', justifyContent: 'center' }}>
                        {isUploading ? (
                            <View style={{ alignItems: 'center', justifyContent: 'center' }}>
                                
                            </View>
                        ) : (
                            images.map((image, index) => (
                                <View key={index} style={styles.uploadWrapperImages}>
                                    <Image
                                        source={{ uri: image.uri }}
                                        style={styles.image}
                                    />
                                    <Text style={{ fontSize: 18, color: '#555', fontWeight: 'bold' }}>{image.fileName}</Text>
                                    <TouchableOpacity onPress={() => deleteImage(index)}>
                                        <MaterialIcons name="delete-outline" size={24} color="red" style={{ marginHorizontal: 8 }} />
                                    </TouchableOpacity>
                                </View>
                            ))
                        )}
                    </View>
                    <TouchableOpacity
                        style={[styles.btnFile, isBtnFileDisabled && { opacity: 0.5 }]}
                        onPress={pickImage}
                        disabled={isBtnFileDisabled}>
                        {isUploading ? (
                            <ActivityIndicator color="#018882" size="small" />
                        ) : (
                            <>
                                <Text style={[styles.buttonText, { color: '#018882' }]}>Select File</Text>
                                <Feather name="upload" size={20} color="#018882" style={{ marginLeft: 10 }} />
                            </>
                        )}
                    </TouchableOpacity>
                </View>


                <TouchableOpacity onPress={handleApply} disabled={imageIds.length === 0 || !startDate || !endDate} style={imageIds.length === 0 || !startDate || !endDate ? styles.disabledButton : styles.submitButton}>
                    <Text style={styles.buttonText}>Apply</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F0F2F4',
        padding: 20,
    },
    form: {
        backgroundColor: '#fff',
        padding: 10,
        borderColor: '#D8D8D8',
        borderWidth: 1,
        borderRadius: 10,
    },
    uploadWrapper: {
        width: '100%',
        minHeight: 120,
        borderWidth: 1,
        borderColor: '#ccc',
        marginBottom: 10,
        borderRadius: 8,
        alignItems: 'flex-end',
        justifyContent: 'space-between',
        padding: 5
    },
    label: {
        fontWeight: 'bold',
        color: '#018882',
        fontSize: 18
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 5,
        padding: 10,
        marginBottom: 10,
    },
    btnFile: {
        backgroundColor: '#fff',
        padding: 10,
        alignItems: 'center',
        borderColor: '#D8D8D8',
        borderWidth: 1,
        borderRadius: 5,
        flexDirection: 'row',
        justifyContent: 'center',
        width: '100%',

    },
    submitButton: {
        backgroundColor: '#018882',
        padding: 10,
        borderRadius: 5,
        alignItems: 'center',
    },
    disabledButton: {
        backgroundColor: '#cccccc',
        padding: 10,
        borderRadius: 5,
        alignItems: 'center',
    },
    buttonText: {
        color: 'white',
        fontWeight: 'bold',
    },
    wrp: {
        width: '100%',
        height: 50,
        alignItems: 'center',
        justifyContent: 'space-between',
        flexDirection: 'row'
    },
    mainText: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#018882',
        marginBottom: 20
    },
    datePicker: {
        width: 140,
        height: 40,
        alignItems: 'center',
        justifyContent: 'space-around',
        borderWidth: 1,
        borderColor: '#D8D8D8',
        borderRadius: 8,
        flexDirection: 'row',
        paddingHorizontal: 10,
    },
    image: {
        width: 50,
        height: 50,
        borderWidth: 1,
        borderColor: '#018882',
        borderRadius: 8
    },
    uploadWrapperImages: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        width: '100%',
        borderWidth: 1,
        borderColor: '#D8D8D8',
        borderRadius: 5,
        overflow: 'hidden',
        padding: 5,
        marginBottom: 5
    },
})