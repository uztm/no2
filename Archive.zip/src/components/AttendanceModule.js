import React, { useState, useEffect } from 'react';
import { View, Text, ActivityIndicator, StyleSheet, Platform } from 'react-native';
import api from '../../api';
import AnimatedLoader from 'react-native-animated-loader';

const AttendanceModule = ({ route }) => {
    const { subject, SEMESTER } = route.params;

    const [absentDates, setAbsentDates] = useState({});
    const [lateDates, setLateDates] = useState({});
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchAllMonthsAttendance(subject);
    }, [subject]);

    const fetchAllMonthsAttendance = (subject) => {
        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

        Promise.all(months.map(month => fetchAttendanceData(subject, month)))
            .then(() => setLoading(false))
            .catch((error) => {
                console.error('Error fetching attendance data: ', error);
                setLoading(false);
            });
    };

    const fetchAttendanceData = (subject, month) => {
        const payload = {
            currentHorizontal: "DAY",
            currentVertical: "MODULE",
            filter: {
                ACADEMIC_YEAR: "YEAR_2023_24",
                SEMESTER: SEMESTER,
                MONTH: month
            },
            horizontalItems: ["ACADEMIC_YEAR", "SEMESTER", "MONTH", "DAY"],
            onlyBootcamp: false,
            onlyGrantee: false,
            verticalItems: ["MODULE", "GROUP", "MENTOR"]
        };

        return api
            .post("university/v2/dashboard/admin/attendance", payload)
            .then((res) => {
                console.log(`API Response for ${month}:`, res.data);

                const subjectData = res.data.data.find(item => item.vertical === subject);
                console.log(`Subject Data for ${month}:`, subjectData);

                if (subjectData) {
                    const absences = {};
                    const lates = {};
                    Object.entries(subjectData).forEach(([day, data]) => {
                        if (day !== "vertical" && data) {
                            if (data.ABSENT > 0) {
                                absences[day] = data.ABSENT;
                            }
                            if (data.LATE > 0) {
                                lates[day] = data.LATE;
                            }
                        }
                    });
                    console.log(`Absent Dates for ${month}:`, absences);
                    console.log(`Late Dates for ${month}:`, lates);
                    setAbsentDates(prevState => ({
                        ...prevState,
                        [month]: absences
                    }));
                    setLateDates(prevState => ({
                        ...prevState,
                        [month]: lates
                    }));
                } else {
                    console.log(`Attendance data not found for ${month}.`);
                }
            })
            .catch(error => {
                console.error(`Error fetching attendance data for ${month}: `, error);
            });
    };

    if (loading) {
        // const { visible } = this.state;
        return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', }}>
                <AnimatedLoader
                    visible={true}
                    overlayColor="rgba(255,255,255)"
                    source={require("../../assets/mine.json")}
                    animationStyle={{width: 400, height: 400}}
                    speed={1}
                >
                    {/* <Text style={{fontWeight: 'bold', color: '#27A49E'}}>Loading...</Text> */}
                </AnimatedLoader>
            </View>
        );
    }

    const displayDates = (dates) => {
        if (!dates || Object.keys(dates).length === 0) {
            return "No data";
        } else {
            return Object.keys(dates).join(', ');
        }
    };

    // Rest of the component code remains the same

    return (
        <View style={styles.container}>
            <View style={styles.cardWrapper}>
                <Text style={styles.subjectName}>{subject}</Text>
                <View style={[styles.colorIndicator, { backgroundColor: '#FF623F' }]}></View>
            </View>
            <View style={{ width: '100%', paddingHorizontal: 10, }}>
                <Text style={[styles.heading]}>Total ABSENTS list:</Text>
            </View>
            <View style={styles.body}>
                {Object.keys(absentDates).length > 0 && (
                    Object.keys(absentDates)
                        .filter(month => Object.keys(absentDates[month]).length > 0)
                        .map(month => (
                            <View style={styles.monthWrp} key={month}>
                                <Text style={styles.monthTitle}>{month}:</Text>
                                <Text style={styles.dateText}>{displayDates(absentDates[month])}</Text>
                            </View>
                        ))
                )}
                {Object.keys(absentDates).length === 0 && (
                    <Text style={{ fontWeight: 'bold', fontSize: 18, color: '#002930', marginVertical: 30, textAlign: 'center' }}>No data available for absences in {subject}.</Text>
                )}
            </View>
            <View style={styles.line}></View>
            <View style={{ width: '100%', paddingHorizontal: 10, }}>
                <Text style={styles.heading}>Total LATES list:</Text>
            </View>
            <View style={styles.body}>
                {Object.keys(lateDates).length > 0 && (
                    Object.keys(lateDates)
                        .filter(month => Object.keys(lateDates[month]).length > 0)
                        .map(month => (
                            <View style={styles.monthWrp} key={month}>
                                <Text style={styles.monthTitle}>{month}:</Text>
                                <Text style={styles.dateText}>{displayDates(lateDates[month])}</Text>
                            </View>
                        ))
                )}
                {Object.keys(lateDates).length === 0 && (
                    <Text style={{ fontWeight: 'bold', fontSize: 18, color: '#002930', marginVertical: 30, textAlign: 'center' }}>No data available for lates in {subject}.</Text>
                )}
            </View>

            {/* <View style={styles.pieChartContainer}>

        </View> */}
        </View>
    );

}

export default AttendanceModule;

const styles = StyleSheet.create({
   
    container: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    cardWrapper: {
        width: '95%',
        paddingVertical: 15,
        backgroundColor: '#fff',
        borderRadius: 15,
        borderColor: '#D8D8D8',
        borderWidth: 1,
        justifyContent: 'space-between',
        flexDirection: 'row',
        marginTop: 10,
        overflow: 'hidden',
        alignItems: 'center',
        marginBottom: 20,
    },
    line: {
        width: '90%',
        height: 1,
        backgroundColor: '#D8D8D8',
        marginVertical: 10
    },
    colorIndicator: {
        width: 50,
        height: '125%',
        borderRadius: 5,
        marginRight: 8
    },
    heading: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#27A49E',
        marginBottom: 10,
        backgroundColor: '#fff',
        paddingHorizontal: 10,
        paddingVertical: 8,
        borderColor: '#D8D8D8',
        borderWidth: 1,
        borderRadius: 8,
    },
    subjectName: {
        ...Platform.select({
            ios: {
                fontSize: 18,
            },
            android: {
                fontSize: 14,
            },
            default: {
                fontSize: 16, // fallback for other platforms
            }
        }),
        flexWrap: 'wrap',
        width: '76.5%',
        fontWeight: 'bold',
        color: '#002930',
        marginLeft: 15,
    },
    body: {
        width: '95%',
        minHeight: 50,
        backgroundColor: '#fff',
        borderColor: '#D8D8D8',
        borderWidth: 1,
        borderRadius: 10,
        alignItems: 'center',
        justifyContent: 'center',
        padding: 5,
        paddingBottom: 10
    },
    monthTitle: {
        fontWeight: 'bold', ...Platform.select({
            ios: {
                fontSize: 18,
            },
            android: {
                fontSize: 14,
            },
            default: {
                fontSize: 16, // fallback for other platforms
            }
        }), color: '#002930'
    },
    dateText: {
        fontWeight: 'bold', ...Platform.select({
            ios: {
                fontSize: 18,
            },
            android: {
                fontSize: 14,
            },
            default: {
                fontSize: 16, // fallback for other platforms
            }
        }), color: '#27A49E', flexWrap: 'wrap',

    },
    monthWrp: {
        width: '98%',
        paddingVertical: 5,
        backgroundColor: '#F0F2F4',
        alignItems: 'center',
        flexDirection: 'column',
        paddingHorizontal: 10,
        borderRadius: 5,
        marginTop: 5,
        flexWrap: 'wrap',
        flexDirection: 'row',
        justifyContent: 'space-between'
    },
    pieChartContainer:{
        width: '90%',
        minHeight: 300,
        backgroundColor: '#fff',
        marginVertical: 20
      }
});

