import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Platform ,TouchableOpacity} from 'react-native';
import api from '../../api';
import { useNavigation } from '@react-navigation/native';

const AttendanceComponent = () => {
    const [attendancePercentage, setAttendancePercentage] = useState(0);

    const calculateAttendancePercentage = (attendanceData) => {
        if (!attendanceData) return 0;

        const { attendance } = attendanceData.data;
        const totalDays = attendance.reduce((acc, curr) => acc + curr.count, 0);
        const totalSatisfactoryDays = attendance.reduce((acc, curr) => {
            if (curr.status === "EXCUSED" || curr.status === "PRESENT") {
                return acc + curr.count;
            }
            return acc;
        }, 0);

        return Math.round((totalSatisfactoryDays / totalDays) * 100);
    };

    const getBackgroundColor = (percentage) => {
        if (percentage >= 80) {
            return "#00B332";
        } else if (percentage >= 75) {
            return "#52C572";
        } else if (percentage >= 65) {
            return "#FFCC1B";
        } else {
            return "#FF623F";
        }
    };

    const getData = () => {
        api
            .get("university/v2/student/dashboard-header")
            .then((res) => {
                const percentage = calculateAttendancePercentage(res.data);
                setAttendancePercentage(percentage);
            })
            .catch((err) => {
                console.log("---", err.response.data);
            });
    };

    useEffect(() => {
        getData();
    }, []);
    const navigation = useNavigation()
    const nav = () => {
        navigation.navigate('Attendence')
    }

    const backgroundColor = getBackgroundColor(attendancePercentage);

    return (
       <>
        <TouchableOpacity onPress={nav} style={[styles.container]}>
            <Text style={[styles.text, { marginLeft: 10 }]}>Total Attendance:</Text>
            <View style={[styles.percentageBox, { backgroundColor }]}>
                <Text style={[styles.text, { color: '#fff', fontSize: 16 }]}>{attendancePercentage}%</Text>
            </View>
        </TouchableOpacity></>
    );
};

const styles = StyleSheet.create({
    container: {
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '98%',
        backgroundColor: '#fff',
        marginVertical: 15,
        borderColor: '#D8D8D8',
        borderWidth: 1,
        borderRadius: 15,
        flexDirection: 'row',
        paddingHorizontal: 10,
        paddingVertical: 10
    },
    text: {
        fontWeight: 'bold',
        color: '#002930',
        ...Platform.select({
            ios: {
                fontSize: 18,
            },
            android: {
                fontSize: 14,
            },
            default: {
                fontSize: 16, // fallback for other platforms
            }
        }),
    },
    percentageBox: {
        width: 50,
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 8
    }
});

export default AttendanceComponent;
