import { StyleSheet, Text, View, Image,Platform, TouchableOpacity, ActivityIndicator } from 'react-native'
import React, { useEffect, useState } from 'react'
import api from '../../api';
import { MaterialCommunityIcons, Feather } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';

const StudentId = () => {
    const [response, setResponse] = useState(null);
    const [photo, setPhoto]=useState();
    const navigation = useNavigation();

    const nav = () => {
        navigation.navigate('StudentID')
    }

    useEffect(() => {
        getData();
    }, []);
    const getData = () => {
        api
            .get("university/v2/student/dashboard-header")
            .then((res) => {
                setResponse(res);
                // console.log(res.data);
            })
            .catch((err) => {
                console.log("---", err.response.data);
            });
    };
    return (
        <TouchableOpacity style={styles.cardWrapper}
            onPress={nav}
        >
            {response ? (
                <View style={styles.content}>
                    <View style={styles.leftContent}>
                        {/* <Image style={styles.image} source={{ uri: response.data.data.fileInfo.url }} /> */}
                        {response.data.data.fileInfo && response.data.data.fileInfo.url ? (
                                <Image style={styles.image} source={{ uri: response.data.data.fileInfo.url }} />
                            ) : (
                                <View style={[styles.image]}>
                                    <Image style={{width: '100%', height: '100%'}} source={require('../../assets/user.png')}/>
                                </View>
                            )}
                        <View>
                            <Text style={styles.nameText}>{response.data.data.firstName}</Text>
                            <Text style={styles.studentIdText}>iD: 220011</Text>
                        </View>
                    </View>
                    <MaterialCommunityIcons name="open-in-new" style={styles.icon} color="#018882" />
                </View>
            ) : (
                <>
                    <View style={styles.content}>
                        <View style={styles.leftContent}>
                            <View style={[styles.image, styles.loading]}  >
                                <Feather name="user" size={48} color="#018882" />
                            </View>
                            <View>
                                <Text style={styles.nameText}><ActivityIndicator size="small" color="#002930" /></Text>
                            </View>
                        </View>
                        <MaterialCommunityIcons name="open-in-new" style={styles.icon}  color="#018882" />
                    </View>
                </>
            )}
        </TouchableOpacity>
    )
}

export default StudentId

const styles = StyleSheet.create({
    cardWrapper: {
        width: '98%',
        ...Platform.select({
            ios: {
              height: 100,
            },
            android: {
                height: 100,
            },
            default: {
                height: 80, // fallback for other platforms
            }
          }),
        backgroundColor: '#fff',
        borderColor: '#D8D8D8',
        borderWidth: 1,
        borderRadius: 20,
        marginBottom: 20
    },
    icon:{
        ...Platform.select({
            ios: {
              fontSize: 34
            },
            android: {
                fontSize: 30
            },
            default: {
                fontSize: 34, // fallback for other platforms
            }
          }),
          marginRight: 5
    },
    content: {
        width: '100%',
        height: '100%',
        padding: 10,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    image: {
        
        borderRadius: 50,
        borderWidth: 2,
        borderColor: '#018882',
        alignItems: 'center',
        justifyContent: 'center',
        ...Platform.select({
            ios: {
              width: 80,
              height: 80,
            },
            android: {
                width: 70,
                height: 70,
            },
            default: {
              width: 80,
              height: 80, // fallback for other platforms
            }
          }),
    },
    leftContent: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    nameText: {
        
        fontWeight: 'bold',
        marginLeft: 15,
        ...Platform.select({
            ios: {
              fontSize: 18,
            },
            android: {
              fontSize: 14,
            },
            default: {
              fontSize: 16, // fallback for other platforms
            }
          })
    },
    studentIdText: {
        marginLeft: 15,
        ...Platform.select({
            ios: {
              fontSize: 16,
            },
            android: {
              fontSize: 12,
            },
            default: {
              fontSize: 16, // fallback for other platforms
            }
          }),
        marginTop: 5,
        color: '#92929D',
    },
    loading: {
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#F0F2F4'
    }
})