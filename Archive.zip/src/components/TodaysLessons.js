import { StyleSheet, Text, View } from 'react-native';
import React, { useEffect, useState } from 'react';
import api from '../../api';

const TodaysLessons = () => {
    const [response, setResponse] = useState();
    const [currentTime, setCurrentTime] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentTime(new Date());
        }, 60000); // Update current time every minute

        return () => clearInterval(timer);
    }, []);

    useEffect(() => {
        const currentDate = new Date();
        const year = currentDate.getFullYear();
        const month = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // Months are zero-based
        const day = currentDate.getDate().toString().padStart(2, '0');
        const formattedDate = `${year}-${month}-${day}`;

        getData(formattedDate);
    }, []);

    const formatTimestampToHourMinute = (timestamp) => {
        const date = new Date(timestamp);
        const hour = date.getHours().toString().padStart(2, '0'); // Pad with leading zero if needed
        const minute = date.getMinutes().toString().padStart(2, '0'); // Pad with leading zero if needed
        return `${hour}:${minute}`;
    };

    const getData = (date) => {
        api.get(`university/v2/student/lessons-by-date/${date}`)
            .then((res) => {
                setResponse(res);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    const isActiveLesson = (startTime, endTime) => {
        const start = new Date(startTime);
        const end = new Date(endTime);
        const current = new Date(currentTime);

        const startTotalMinutes = start.getHours() * 60 + start.getMinutes();
        const endTotalMinutes = end.getHours() * 60 + end.getMinutes();
        const currentTotalMinutes = current.getHours() * 60 + current.getMinutes();

        return currentTotalMinutes >= startTotalMinutes && currentTotalMinutes <= endTotalMinutes;
    };

    return (
        <View style={{ width: '98%', marginTop: 15, borderRadius: 12 }}>
            <View style={styles.header}>
                <Text style={styles.title}>Today's Lessons:</Text>
                <Text style={styles.title}>{response && response.data.data[0].date}</Text>
            </View>
            <View style={styles.container}>
                {response ? (
                    response.data.data.map((module, index) => (
                        <View key={module.id} style={[styles.lessonContainer, isActiveLesson(module.startTime, module.endTime) && { borderColor: '#52C572', borderWidth: 1.5 }]}>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 }}>
                                <Text style={styles.moduleName}>{module.modulName}</Text>
                                {isActiveLesson(module.startTime, module.endTime) && (
                                    <View style={{ paddingHorizontal: 10, backgroundColor: '#52C572', alignItems: 'center', justifyContent: 'center', borderRadius: 8 }}>
                                        <Text style={styles.activeText}>Active</Text>
                                    </View>
                                )}
                            </View>
                            {index !== response.data.data.length - 5 && <View style={{ borderBottomWidth: 1, borderBottomColor: '#ccc', marginBottom: 10 }} />}
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                <Text style={styles.mentorName}>{module.mentor && module.mentor.fullName}</Text>
                                <Text style={styles.date}>{formatTimestampToHourMinute(module.startTime)} - {formatTimestampToHourMinute(module.endTime)}</Text>
                            </View>
                        </View>
                    ))
                ) : (
                    <Text style={styles.moduleName}>Today no lessons</Text>
                )}
            </View>
        </View>
    );
};

export default TodaysLessons;

const styles = StyleSheet.create({
    title: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#fff',
    },
    header: {
        width: '100%',
        height: 40,
        backgroundColor: '#018882',
        borderColor: '#D8D8D8',
        borderTopWidth: 1,
        borderLeftWidth: 1,
        borderRightWidth: 1,
        borderStartStartRadius: 12,
        borderStartEndRadius: 12,
        justifyContent: 'space-between',
        alignItems: 'center',
        flexDirection: 'row',
        paddingHorizontal: 15,

    },
    activeText: {
        fontWeight: 'bold',
        color: '#fff'
    },
    container: {
        borderEndEndRadius: 15,
        borderEndStartRadius: 15,
        overflow: 'hidden',
        borderColor: '#D8D8D8',
        borderWidth: 1,
        width: '100%',
        backgroundColor: '#fff',
        paddingTop: 10
    },
    lessonContainer: {
        marginHorizontal: 10,
        backgroundColor: '#F0F2F4',
        padding: 10,
        borderRadius: 10,
        marginBottom: 10,
        borderColor: '#ccc',
    },
    moduleName: {
        fontSize: 16,
        fontWeight: 'bold',
        marginBottom: 10,
        color: '#002930',
        flexWrap: 'wrap',
    },
    mentorName: {
        fontSize: 14,
        fontWeight: '500',
        color: '#555'
    },
    date: {
        fontSize: 14,
        fontWeight: '500',
        color: '#555',
    },
});
