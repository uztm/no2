//StudentData.js
import { ActivityIndicator, StyleSheet, Text, View, Platform } from 'react-native'
import React, { useEffect, useState } from 'react'
import api from '../../api';

const StudentData = () => {

    const [response, setResponse] = useState(null);
    const [response2, setResponse2] = useState(null);

    useEffect(() => {
        getData2();
        getData();
    }, []);



    const getData2 = () => {
        api
            .get("university/v2/calendar/filter-element-student")
            .then((res) => {
                setResponse2(res);
                console.log(res.data.data.rooms[0].name);
            })
            .catch((err) => {
                console.log("---", err.response.data);
            });
    };

    const getData = () => {
        api
            .get("university/v2/student/dashboard-header")
            .then((res) => {
                setResponse(res);
                // console.log(res.data);
            })
            .catch((err) => {
                console.log("---", err.response.data);
            });
    };

    return (
        <View style={styles.cardWrapper}>
            <View style={styles.header}>
                <Text style={styles.infoTextHeader}>Student info:</Text>
            </View>
            <View style={styles.bodyContent}>
                {response && response2 ? (
                    <>
                        <View style={styles.contentWrapper}>
                            <Text style={styles.text}>Name:</Text>
                            <Text style={styles.text}>{response.data.data.firstName} {response.data.data.lastName}</Text>
                        </View>
                        <View style={styles.contentWrapper}>
                            <Text style={styles.text}>Student iD:</Text>
                            <Text style={styles.text}>220011</Text>
                        </View>
                        <View style={styles.contentWrapper}>
                            <Text style={styles.text}>Group iD:</Text>
                            <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
                                {response.data.data.groups.slice(0, 2).map(group => (
                                    <Text key={group.id} style={[styles.text, { marginLeft: 10 }]}>{group.name}</Text>
                                ))}

                            </View>
                        </View>
                        <View style={styles.contentWrapper}>
                            <Text style={styles.text}>Class room:</Text>
                            <Text style={styles.text}>{response2.data.data.rooms.length > 0 ? response2.data.data.rooms[0].name : 'No room found'}</Text>
                        </View>

                    </>
                ) : (
                    <>
                        <View style={styles.contentWrapper}>
                            <Text style={styles.text}>Name:</Text>
                            <Text style={styles.text}><ActivityIndicator size="small" color="#002930" /></Text>
                        </View>
                        <View style={styles.contentWrapper}>
                            <Text style={styles.text}>Student iD:</Text>
                            <Text style={styles.text}><ActivityIndicator size="small" color="#002930" /></Text>
                        </View>
                        <View style={styles.contentWrapper}>
                            <Text style={styles.text}>Group iD:</Text>
                            <Text style={styles.text}><ActivityIndicator size="small" color="#002930" /></Text>
                        </View>
                        <View style={styles.contentWrapper}>
                            <Text style={styles.text}>Class room:</Text>
                            <Text style={styles.text}><ActivityIndicator size="small" color="#002930" /></Text>
                        </View>
                    </>
                )}
            </View>
        </View>
    )
}

export default StudentData

const styles = StyleSheet.create({
    cardWrapper: {
        width: '98%',
        // height: 200,
        backgroundColor: '#fff',
        borderColor: '#D8D8D8',
        borderWidth: 1,
        borderRadius: 15,
        overflow: 'hidden',
        paddingBottom: 12
    },
    header: {
        width: '100%',
        height: 40,
        backgroundColor: '#018882',
        borderTopEndRadius: 15,
        borderStartStartRadius: 15,
        paddingHorizontal: 15,
        justifyContent: 'center',
    },
    infoTextHeader: {
        
        fontWeight: 'bold',
        color: '#fff',
        ...Platform.select({
            ios: {
              fontSize: 18,
            },
            android: {
              fontSize: 14,
            },
            default: {
              fontSize: 16, // fallback for other platforms
            }
          })
    },
    bodyContent: {
        width: '100%',
        // backgroundColor: 'yellow',
        paddingHorizontal: 10,
    },
    contentWrapper: {
        width: '100%',
        height: 40,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: '#F0F2F4',
        paddingHorizontal: 10,
        marginTop: 10,
        borderRadius: 8,
    },
    text: {
        fontWeight: 'bold',
        color: '#002930',
        ...Platform.select({
          ios: {
            fontSize: 16,
          },
          android: {
            fontSize: 14,
          },
          default: {
            fontSize: 16, // fallback for other platforms
          }
        })
      }
})