import { StyleSheet, Text, View, TouchableOpacity, ScrollView, Modal } from 'react-native'
import React, { useEffect, useState } from 'react'
import { Octicons, AntDesign } from '@expo/vector-icons';
import AnimatedLoader from 'react-native-animated-loader';
import { useNavigation } from '@react-navigation/native';

const StudentsMc = () => {
  const [petitions, setPetitions] = useState([]);
  const [openCommentIndex, setOpenCommentIndex] = useState(null);
  const [loading, setLoading] = useState(true);

  const navigation = useNavigation();

  const nav = () => {
    navigation.navigate('AddNewMc')
  }
  useEffect(() => {
    fetchData();
  }, []);

  const handleComment = (index) => {
    setOpenCommentIndex(index === openCommentIndex ? null : index);
  }

  const fetchData = async () => {
    try {
      // Fetch data from the endpoint
      const response = await fetch('https://api.pdp.university/api/university/v2/mitigating-circumstance/petitions');
      const json = await response.json();
      // Set petitions state with the data from the response
      setPetitions(json.data);
      setLoading(false)
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <AnimatedLoader
          visible={true}
          overlayColor="rgba(255,255,255)"
          source={require("../../assets/mine.json")}
          animationStyle={{ width: 400, height: 400 }}
          speed={1}
        >
          {/* <Text style={{fontWeight: 'bold', color: '#27A49E'}}>Loading...</Text> */}
        </AnimatedLoader>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={{ fontWeight: 'bold', color: '#10857C', fontSize: 16 }}>Student's MC</Text>
        <TouchableOpacity style={styles.addBtn} onPress={nav}>
          <Text style={{ fontWeight: 'bold', color: '#fff' }}>Add new</Text>
          <AntDesign name="addfile" size={16} style={{ marginLeft: 5 }} color="#fff" />
        </TouchableOpacity>
      </View>
      <ScrollView style={{ width: '100%', marginBottom: 20}}>
        <View style={{ borderRadius: 15, overflow: 'hidden', borderColor: '#D8D8D8', borderWidth: .5, }}>
          {petitions.map((petition, index) => (
            <View key={index + 1} style={{ alignItems: 'center' }}>
              <View key={index + 1} style={styles.card}>
                <View style={{minWidth:20, alignItems: 'center', justifyContent: 'center', color: '#555'}}>
                  <Text style={{fontWeight: 'bold'}}>{petitions.length - index}</Text>
                </View>
                <View style={[styles.status, { backgroundColor: petition.status === 'REJECTED' ? '#DE5471' : petition.status === 'CONFIRMED' ? '#65B072' : '#D8D8D8' }]}>
                  <Text style={[styles.statusText,]}>{petition.status}</Text>
                </View>
                <View style={styles.dateWrp}>
                  <Text style={[styles.dateTimeText, { marginBottom: 3 }]}>
                    {/* Format start date */}
                    {new Date(petition.startDate).toLocaleDateString()}
                  </Text>
                  <Text style={styles.dateTimeText}>
                    {/* Format end date */}
                    {new Date(petition.endDate).toLocaleDateString()}
                  </Text>
                </View>
                <View style={{ minWidth: 20, alignItems: 'center', justifyContent: 'center' }}>
                  {petition.rejectDescription ? (
                    <TouchableOpacity onPress={() => handleComment(index)}>
                      <Octicons name="comment" size={24} color="#444" />
                    </TouchableOpacity>
                  ) : (
                    <Text style={styles.noCommentText}>...</Text>
                  )}
                </View>
              </View>
              <View style={{ width: '90%', height: 1, backgroundColor: 'transparent' }}></View>
              {/* Modal for reject description */}
              <Modal
                visible={openCommentIndex === index}
                transparent={true}
                animationType="fade"
                onRequestClose={() => handleComment(index)}
              >
                <View style={styles.modalContainer}>
                  <View style={styles.modalContent}>
                    <Text style={styles.modalText}>{petition.rejectDescription}</Text>
                    <TouchableOpacity onPress={() => handleComment(index)} style={styles.closeButton}>
                      <Text style={styles.closeButtonText}>Close</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </Modal>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  )
}

export default StudentsMc

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'start',
    backgroundColor: '#F2F2F2',
    padding: 10,
  },
  header: {
    width: '100%',
    height: 50,
    backgroundColor: '#fff',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 10,
    borderColor: '#D8D8D8',
    borderWidth: 1,
    borderRadius: 10,
    marginBottom: 20
  },
  addBtn: {
    flexDirection: 'row',
    paddingVertical: 8,
    backgroundColor: '#65B072',
    borderRadius: 5,
    paddingHorizontal: 10,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  card: {
    width: '100%',
    minHeight: 60,
    backgroundColor: '#fff',
    padding: 10,
    alignItems: 'center',
    flexDirection: 'row',
    paddingHorizontal: 15,
    justifyContent: 'space-between'
  },
  status: {
    borderRadius: 5,
    marginHorizontal: 10,
    paddingVertical: 5,
    paddingHorizontal: 5,
    backgroundColor: '#D8D8D8',
    minWidth: 100,
    alignItems: 'center',
    justifyContent: 'center'
  },
  statusText: {
    fontWeight: 'bold',
    color: '#fff'
  },
  dateWrp: {
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 100
  },
  dateTimeText: {
    fontWeight: '500',
    color: '#555',
    fontSize: 12
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 10,
    elevation: 5,
    alignItems: 'center',
    justifyContent: 'center',
    width: '80%',
  },
  modalText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  closeButton: {
    backgroundColor: '#65B072',
    padding: 10,
    borderRadius: 5,
    paddingHorizontal: 20,
    marginTop: 10,
  },
  closeButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  noCommentText: {
    fontSize: 18,
    color: '#555',
  },
})
