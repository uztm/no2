import { StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React from 'react'
import { AntDesign } from '@expo/vector-icons'; // Import reload icon from Expo icons

const StudentsSurvey = () => {
  
  return (
    <View style={styles.container}>
    <Text style={{fontSize: 18, fontWeight: 'bold', marginBottom: 10}}>Error: </Text>
    <TouchableOpacity  style={{width: 150, height: 40, backgroundColor: '#10857C', alignItems: 'center', justifyContent: 'center', borderRadius: 20}}>
        <AntDesign name="reload1" size={24} color="#fff" />
    </TouchableOpacity>
</View>
  )
}

export default StudentsSurvey

const styles = StyleSheet.create({
    container:{
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    }
})