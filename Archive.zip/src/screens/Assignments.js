import { StyleSheet, Text, View, TouchableOpacity, ScrollView } from 'react-native'
import React, { useEffect, useState } from 'react'
import api from '../../api';
import { useNavigation } from '@react-navigation/native';

const Assignments = () => {
    const [response, setResponse] = useState(null);

    const getData = () => {
        api
            .get("university/v2/assignment/get-student-assignments")
            .then((res) => {
                setResponse(res);
                console.log(res.data);
            })
            .catch((err) => {
                console.log(err.response.data);
            });
    };

    useEffect(() => {
        getData();
    }, []);

    const navigation = useNavigation();

    const handleAssignmentPress = (assignmentId) => {
        navigation.navigate('AssignmentDetails', { assignmentId });
    };

    return (
        <View style={{ alignItems: 'center', justifyContent: 'center' }}>
            <View style={styles.headerTop}>
                <Text style={{fontWeight: 'bold', color: '#10857C', fontSize: 16}}>Student Assignments</Text>
            </View>
            <ScrollView style={{ flexGrow: 2, marginBottom: 40, width: '100%' }}>
                <View style={styles.container}>
                    {response && response.data.data.map((item, index) => (
                        <TouchableOpacity style={styles.card} key={index} onPress={()=>handleAssignmentPress(item.assignmentId)}>
                            <View style={styles.header}>
                                <Text style={styles.assessmentName}>{item.assessmentName}</Text>
                                <View style={styles.assessmentTypeWrp}>
                                    <Text style={styles.assessmentType}>{item.assessmentType}</Text>
                                </View>
                            </View>
                            <View style={{ width: '100%', height: .6, backgroundColor: '#ccc', marginTop: 5 }}></View>
                            <View style={styles.body}>
                                <Text style={styles.modulePlanName}>{item.modulePlanName}</Text>
                                <Text style={styles.date}>Available From: {new Date(item.availableFrom).toLocaleDateString()}</Text>
                                <Text style={styles.date}>Due Date: {new Date(item.dueDate).toLocaleDateString()}</Text>
                                <View style={{width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10}}>
                                <Text style={styles.date}>Online Entry Options: </Text>
                                <Text style={[styles.date, {color: '#002930'}]}>{item.onlineEntryOptions}</Text>
                                </View>
                            </View>
                        </TouchableOpacity>
                    ))}
                </View>
            </ScrollView>
        </View>
    )
}

export default Assignments

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'start',
        paddingBottom: 20,
    },
    headerTop: {
        width: '95%',
        height: 50,
        backgroundColor: '#fff',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 10,
        borderColor: '#D8D8D8',
        borderWidth: 1,
        borderRadius: 10,
        marginBottom: 5,
        marginTop: 10,
    },
    card: {
        width: '95%',
        minHeight: 100,
        backgroundColor: '#fff',
        marginVertical: 5,
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 15,
        overflow: 'hidden',
        paddingTop: 5,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 10,
        paddingVertical: 5,
    },
    assessmentName: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#10857C',
    },
    assessmentTypeWrp: {
        backgroundColor: '#65B072',
        paddingHorizontal: 10,
        paddingVertical: 2,
        borderRadius: 5,
    },
    assessmentType: {
        fontWeight: 'bold',
        fontSize: 16,
        color: '#fff'
    },
    body: {
        width: '100%',
        padding: 10
    },
    modulePlanName: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#002930',
        marginBottom: 10
    },
    date:{
        fontSize: 14,
        fontWeight: '600',
        color: '#555',
    }
})

// 002930
