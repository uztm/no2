import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import api from '../../api';

const AssignmentDetails = ({ route }) => {
    const { assignmentId } = route.params;
    const [data, setData] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await api.get(`university/v2/submission/get-student-submissions/${assignmentId}`);
                setData(response.data);
            } catch (error) {
                console.error('Error fetching assignment details:', error);
            }
        };
        fetchData();
    }, [assignmentId]);

    if (!data) {
        return (
            <View style={styles.container}>
                <Text style={styles.loadingText}>Loading...</Text>
            </View>
        );
    }

    return (
        <ScrollView contentContainerStyle={styles.scrollContainer}>
            <View style={styles.container}>
                <View style={styles.assignmentInfo}>
                    <Text style={styles.title}>Assignment Details</Text>
                    {/* Render assignment information */}
                    <Text style={styles.subtitle}>Assignment ID: {assignmentId}</Text>
                    <Text style={styles.subtitle}>Assignments:</Text>
                    {data.data.assigns.map((assign) => (
                        <View key={assign.id} style={styles.assignment}>
                            <Text style={styles.assignmentText}>Mentor: {assign.mentor.name}</Text>
                            <Text style={styles.assignmentText}>Due Date: {new Date(assign.due).toLocaleDateString()}</Text>
                        </View>
                    ))}
                </View>
                <View style={styles.submissionInfo}>
                    <Text style={styles.subtitle}>Submissions:</Text>
                    {data.data.submissions.map((submission) => (
                        <View key={submission.id} style={styles.submission}>
                            <Text style={[styles.submissionText,]}>Submission ID: <Text style={{fontWeight: 'bold'}}>{submission.id}</Text></Text>
                            <Text style={styles.submissionText}>Status: {submission.status}</Text>
                            <Text style={styles.submissionText}>Grade: {submission.grade}</Text>
                            <Text style={styles.submissionText}>Student Comment: {submission.studentComment}</Text>
                            {/* Render other submission details */}
                        </View>
                    ))}
                </View>
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    scrollContainer: {
        flexGrow: 1,
        backgroundColor: '#fff',
        paddingHorizontal: 10,
        paddingVertical: 10,
        paddingBottom: 50
    },
    container: {
        flex: 1,
        padding: 20,
        backgroundColor: '#fff',
        // borderRadius: 10,
        // borderWidth: .3,
        // borderColor: '#ccc'
    },
    loadingText: {
        fontSize: 18,
        fontWeight: 'bold',
        textAlign: 'center',
        marginTop: 20,
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
        color: '#10857C',
    },
    subtitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginTop: 20,
        color: '#10857C',
        marginBottom: 10
    },
    assignmentInfo: {
        marginBottom: 30,
    },
    submissionInfo: {
        borderTopWidth: 1,
        borderTopColor: '#ccc',
        paddingTop: 20,
    },
    assignment: {
        marginBottom: 15,
    },
    submission: {
        marginBottom: 30,
    },
    assignmentText: {
        fontSize: 16,
        color: '#333',
        marginBottom: 5,
    },
    submissionText: {
        fontSize: 16,
        color: '#555',
        marginBottom: 5,
    },
});

export default AssignmentDetails;
