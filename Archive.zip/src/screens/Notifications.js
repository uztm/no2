import { ActivityIndicator, ScrollView, StyleSheet, Text, View } from 'react-native';
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Notifications = () => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('https://api.pdp.university/api/university/v2/notification/all');
        setNotifications(response.data.data.notifications);
        setLoading(false)
      } catch (error) {
        console.error('Error fetching notifications:', error);
      }
    };

    fetchData();
  }, []);

  const getTimeDifference = (timestamp) => {
    const currentTime = new Date();
    const messageTime = new Date(timestamp);
    const difference = currentTime - messageTime;
    const seconds = Math.floor(difference / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (seconds < 60) {
      return 'Just now';
    } else if (minutes < 60) {
      return minutes === 1 ? '1 minute ago' : `${minutes} minutes ago`;
    } else if (hours < 24) {
      return hours === 1 ? '1 hour ago' : `${hours} hours ago`;
    } else {
      return messageTime.toLocaleDateString();
    }
  };
  if (loading) {
    return (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
           <ActivityIndicator size="large" color="#002930"  />
        </View>
    );
}

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {notifications?(
        notifications.map(notification => (
          <View key={notification.notificationId} style={styles.messageContainer}>
  
            <Text style={styles.senderName}>{notification.senderFirstName} {notification.senderLastName}</Text>
            <View style={styles.messageBubble}>
              <Text style={styles.title}>{notification.title} </Text>
              <Text style={styles.messageText}>{notification.text}</Text>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={styles.timestamp}>{getTimeDifference(notification.sendDate)}</Text>
              </View>
            </View>
  
          </View>
        ))
      ):(
        <Text>No data</Text>
      )}
    </ScrollView>
  );
};

export default Notifications;

const styles = StyleSheet.create({
  container: {
    paddingVertical: 10,
    paddingHorizontal: 15,
    paddingBottom: 50
  },
  messageContainer: {
    marginBottom: 20,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  senderName: {
    marginBottom: 5,
    fontWeight: 'bold',
    color: '#555',
    marginLeft: 5
  },
  messageBubble: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#D8D8D8',
  },
  messageText: {
    fontSize: 16,
    color: '#000',
  },
  timestamp: {
    color: '#999',
    fontSize: 12,
    marginTop: 5,
  },
});
