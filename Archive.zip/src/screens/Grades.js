import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Platform, ActivityIndicator } from 'react-native';
import axios from 'axios';
import { AntDesign } from '@expo/vector-icons';
import AnimatedLoader from 'react-native-animated-loader';

const API_URL = 'https://api.pdp.university/api/university/v2/assignment/get-student-assignments';
const SUBMISSION_API_URL = 'https://api.pdp.university/api/university/v2/submission/get-student-submissions/';

const getColorForGrade = (gradeName) => {
    switch (gradeName) {
        case 'D':
            return '#16CF4A';
        case 'M':
            return '#80DB9A';
        case 'P':
            return '#FFCD20';
        case 'U':
            return '#FF623F';
        case 'N/A':
            return 'red';
        default:
            return '#D8D8D8'; // Default color if grade name doesn't match any case
    }
};

const GradeComponent = () => {
    const [assignments, setAssignments] = useState([]);
    const [grades, setGrades] = useState({});
    const [loading, setLoading] = useState(true);
    const [dataFetched, setDataFetched] = useState(false); // New state to track data fetching completion

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(API_URL);
                setAssignments(response.data.data);

                const gradesData = {};
                for (const assignment of response.data.data) {
                    const grade = await fetchGradeForAssignment(assignment.assignmentId);
                    gradesData[assignment.assignmentId] = grade;
                }
                setGrades(gradesData);
                setLoading(false);
                setDataFetched(true); // Set data fetching completion
            } catch (error) {
                console.error('Error fetching assignments:', error);
            }
        };

        fetchData();
    }, []);

    const fetchGradeForAssignment = async (assignmentId) => {
        try {
            const response = await axios.get(`${SUBMISSION_API_URL}${assignmentId}`);
            const submissions = response.data.data.submissions;
            const latestSubmission = submissions[0];
            return latestSubmission.grade || 'N/A';
        } catch (error) {
            console.error('Error fetching assignment details:', error);
            return 'N/A';
        }
    };

    if (loading) {
        return (
            <View style={styles.loaderContainer}>
                <AnimatedLoader
                    visible={true}
                    overlayColor="rgba(255,255,255)"
                    source={require('../../assets/mine.json')}
                    animationStyle={{width: 400, height: 400}}
                    speed={1}
                >
                    {/* <Text style={{fontWeight: 'bold', color: '#27A49E'}}>Loading...</Text> */}
                </AnimatedLoader>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <View style={styles.semesterNameWrapper}>
                <Text style={styles.semName}>Semester-1</Text>
                <AntDesign name="staro" size={24} color="#018882" />
            </View>
            <View style={styles.wrapper}>
                <View style={styles.header}>
                    <Text style={styles.headerText}>Module name:</Text>
                    <Text style={styles.headerText}>Grade:</Text>
                </View>
                <View style={styles.body}>
                    {assignments.map((assignment, index) => (
                        <View key={index} style={styles.element}>
                            <Text style={styles.subName}>{assignment.modulePlanName}</Text>
                            <View style={[styles.gradeNameBox, { backgroundColor: getColorForGrade(grades[assignment.assignmentId]?.substring(0, 1)) }]}>
                                <Text style={styles.gradeName}>{grades[assignment.assignmentId]?.substring(0, 1)}</Text>
                            </View>
                        </View>
                    ))}
                </View>
            </View>
        </View>
    );
};

export default GradeComponent;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'start'
    },
    loaderContainer: {
        height: '50%',
        alignItems: 'center',
        justifyContent: 'center'
    },
    semesterNameWrapper: {
        width: '95%',
        height: 50,
        backgroundColor: '#fff',
        borderColor: '#D8D8D8',
        borderWidth: 1,
        marginVertical: 10,
        justifyContent: 'space-between',
        paddingHorizontal: 15,
        borderRadius: 15,
        flexDirection: 'row',
        alignItems: 'center'
    },
    semName: {
        ...Platform.select({
            ios: {
                fontSize: 18,
            },
            android: {
                fontSize: 14,
            },
            default: {
                fontSize: 16, // fallback for other platforms
            }
        }),
        fontWeight: 'bold',
        color: '#018882',
    },
    wrapper: {
        width: '95%',
        backgroundColor: '#fff',
        borderRadius: 15,
        overflow: 'hidden',
        borderColor: '#D8D8D8',
        borderWidth: 1,
    },
    header: {
        width: '100%',
        height: 50,
        backgroundColor: '#018882',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 15
    },
    headerText: {
        ...Platform.select({
            ios: {
                fontSize: 18,
            },
            android: {
                fontSize: 14,
            },
            default: {
                fontSize: 16, // fallback for other platforms
            }
        }),
        fontWeight: 'bold',
        color: '#fff'
    },
    body: {
        padding: 10,
    },
    element: {
        flexDirection: 'row',
        width: '100%',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginVertical: 5,
        backgroundColor: '#F0F2F4',
        paddingVertical: 5,
        paddingHorizontal: 10,
        borderRadius: 8,
    },
    subName: {
        width: '80%',
        flexWrap: 'wrap',
        ...Platform.select({
            ios: {
                fontSize: 16,
            },
            android: {
                fontSize: 14,
            },
            default: {
                fontSize: 16, // fallback for other platforms
            }
        }),
        fontWeight: 'bold',
        color: '#002930'
    },
    gradeNameBox: {
        width: 30,
        height: 30,
        alignItems: 'center',
        justifyContent: 'center',
        padding: 5,
        borderRadius: 5,
    },
    gradeName: {
        ...Platform.select({
            ios: {
                fontSize: 16,
            },
            android: {
                fontSize: 12,
            },
            default: {
                fontSize: 16, // fallback for other platforms
            }
        }),
        fontWeight: 'bold',
        color: '#fff',
    }
});
