import { StyleSheet, Text, View, Image, ActivityIndicator, ScrollView } from 'react-native'
import React, { useEffect, useState } from 'react'
import api from '../../api';
import { Feather } from '@expo/vector-icons';

const StudentIdScreen = ({StudentID}) => {

    const photo = StudentID;

    const [response, setResponse] = useState();

    useEffect(() => {
        // getData2();
        getData();
    }, []);

    const getData = () => {
        api
            .get("university/v2/student/dashboard-header")
            .then((res) => {
                setResponse(res);
                // console.log(res.data);
            })
            .catch((err) => {
                console.log("---", err.response.data);
            });
    };

    return (
        <View style={styles.container}>
            
            {response ? (
                <View style={styles.idContainer}>
                    <View style={styles.idHeader}>
                        <Image style={styles.idLOGO} source={require('../../assets/idLOGO.png')} />
                        <Text style={styles.idHeaderText}>Student iD Card</Text>
                    </View>
                    <View style={styles.idBody}>
                        <View style={[styles.row, styles.imageContainer]}>
                            {response.data.data.fileInfo && response.data.data.fileInfo.url ? (
                                <Image style={styles.image} source={{ uri: response.data.data.fileInfo.url }} />
                            ) : (
                                <View style={[styles.image]}>
                                    <Feather style={styles.user} name="user" size={58} color="#002930" />
                                    <Text style={styles.lTExt}>To see your PHOTO here</Text>
                                    <Text style={styles.lTExt}>Upload your PHOTO from web version</Text>
                                </View>
                            )}
                        </View>
                        <View style={[styles.row, styles.textWrapper]}>
                            <View>
                                <Text style={styles.title}>Last name:</Text>
                                <Text style={styles.text}>{response.data.data.lastName}</Text>
                            </View>
                            <View>
                                <Text style={styles.title}>First name:</Text>
                                <Text style={styles.text}>{response.data.data.firstName}</Text>
                            </View>
                            <View>
                                <Text style={styles.title}>Student iD</Text>
                                <Text style={styles.text}>220011</Text>
                            </View>
                        </View>
                        <View style={[styles.row, styles.barcode]}>
                            <Image style={{height: '90%'}} source={require('../../assets/barcode.png')} />
                        </View>
                    </View>
                </View>
            ) : (
                <ActivityIndicator size="large" color="#fff" />
            )}
            
        </View>
    )
}

export default StudentIdScreen

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#018882',
    },
    idContainer: {
        width: '170%',
        height: '50%',
        backgroundColor: '#fff',
        borderRadius: 30,
        transform: [{ rotate: '90deg' }],
        overflow: 'hidden'
    },
    idHeader: {
        width: '100%',
        height: '20%',
        backgroundColor: '#002930',
        borderStartEndRadius: 28,
        borderStartStartRadius: 28,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 20,
    },
    idLOGO: {
        width: 120,
        height: 45,
    },
    idHeaderText: {
        fontWeight: 'bold',
        color: '#fff',
        fontSize: 18,
    },
    idBody: {
        width: '100%',
        height: '75%',
        borderRadius: 20,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-around',
        overflow: 'hidden',
        paddingTop: 10
    },
    row: {
        width: '30%',
    },
    imageContainer: {
        padding: 15,
        backgroundColor: '#fff',
        alignItems: 'center',
        height: '100%',
        justifyContent: 'center',
        position: 'relative'
    },
    user: {
        // position: 'absolute',
        zIndex: 2,
    },
    image: {
        width: '100%',
        height: '110%',
        borderRadius: 20,
        alignItems: 'center',
        backgroundColor: '#F2F2F2',
        justifyContent: 'center',
    },
    lTExt:{
        fontSize: 8,
    },
    title: {
        color: '#27A49E',
        fontSize: 18,
        fontWeight: '500'
    },
    text: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#002930'
    },
    textWrapper: {
        alignItems: 'start',
        justifyContent: 'space-between',
        height: '90%'
    },
    barcode: {
        alignItems: 'center',
        justifyContent: 'center'
    }
})
