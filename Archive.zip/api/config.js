

export const BASE_URL = "https://api.pdp.university/api/";