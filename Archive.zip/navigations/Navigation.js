import React, { useEffect, useState } from 'react';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Home from '../screens/Home';
import SignIn from '../screens/SignIn';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import api from '../api';
import { Octicons, Ionicons } from '@expo/vector-icons';
import Attendence from '../screens/Attendence';
import Calendar from '../screens/Calendar';
import More from '../screens/More';
import { Image, Text, TouchableOpacity, View, Platform } from 'react-native'
import StudentIdScreen from '../src/screens/StudentIdScreen';
import AttendanceModule from '../src/components/AttendanceModule';
import GradeComponent from '../src/screens/Grades';
import StudentsMc from '../src/screens/StudentsMc';
import Notifications from '../src/screens/Notifications';
import NewMc from '../src/modals/NewMc';
import StudentsSurvey from '../src/screens/StudentsSurvey';
import Assignments from '../src/screens/Assignments';
import AssignmentDetails from '../src/screens/AssignmentDetails';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

export const AuthContext = React.createContext({
    isLoggedIn: false,
});

const Navigation = () => {
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    useEffect(() => {
        checkLoginStatus();
        AsyncStorage.getItem("token")
            .then((res) => {
                if (res) {
                    setOpen(true);
                    api.defaults.headers.common["Authorization"] = `Bearer ${res}`;
                    AsyncStorage.getItem("refresh").then((res) => {
                        api.defaults.headers.common["Cookie"] = `refreshToken = ${res}`;
                    });
                }
            })
            .catch((err) => {
                console.log(err);
            });
    }, []);

    const checkLoginStatus = async () => {
        try {
            const token = await AsyncStorage.getItem('token');
            const refresh = await AsyncStorage.getItem('refresh');
            if (token && refresh) {
                setIsLoggedIn(true);
            } else {
                setIsLoggedIn(false);
            }
        } catch (error) {
            console.error('Error checking login status:', error);
        }
    };

    const logOut = async () => {
        try {
            await AsyncStorage.clear();
            setIsLoggedIn(false);
        } catch (error) {
            console.error('Error logging out:', error);
        }
    };

    const activate = () => {
        setIsLoggedIn(true);
    };

    const HomeTabs = () => {
        const navigation = useNavigation();
        return (
            <Tab.Navigator
                screenOptions={({ route }) => {
                    // Define styles for active and inactive icons

                    let iconName;
                    let activeTabColor = '#018882';
                    let inactiveTabColor = '#92929D';

                    if (route.name === 'Home') {
                        iconName = 'home';
                    } else if (route.name === 'Attendence') {
                        iconName = 'checklist';
                    } else if (route.name === 'Calendar') {
                        iconName = 'calendar';
                    } else if (route.name === 'More') {
                        iconName = 'package';
                    }

                    // Return the tabBarIcon component with the determined icon name and styles
                    return {
                        tabBarIcon: ({ color }) => (
                            <View >
                                <Octicons
                                    name={iconName}
                                    style={{
                                        ...Platform.select({
                                            ios: {
                                                fontSize: 28,
                                            },
                                            android: {
                                                fontSize: 24,
                                            },
                                            default: {
                                                fontSize: 16, // fallback for other platforms
                                            }
                                        })
                                    }}
                                    color={color}
                                />
                            </View>
                        ),
                        tabBarActiveTintColor: activeTabColor,
                        tabBarInactiveTintColor: inactiveTabColor,
                        tabBarStyle: {
                            // 
                            ...Platform.select({
                                ios: {
                                    height: 85,
                                    paddingTop: 5,
                                },
                                android: {


                                },
                                default: {
                                    paddingTop: 5,
                                    height: 90, // fallback for other platforms
                                }
                            })
                        },
                        // tabBarShowLabel: false,
                    };
                }}
            >
                <Tab.Screen
                    name="Home"
                    component={Home}
                    options={{
                        headerTitle: ' ',
                        headerLeft: () => (
                            <Image source={require('../assets/logoPDP.png')} style={{ width: 130, height: 45, marginLeft: 15, marginBottom: 5 }} />
                        ),
                        headerRight: () => (
                            <TouchableOpacity onPress={() => navigation.navigate('Notifications')} style={{ marginRight: 20 }}>
                                <Octicons name="bell" size={28} color="#018882" />
                            </TouchableOpacity>
                        ),
                    }}
                />
                <Tab.Screen
                    name="Attendence"
                    component={Attendence}
                    options={{
                        headerTitle: ' ',
                        headerLeft: () => (
                            <View style={{ flexDirection: 'row', marginLeft: 15, alignItems: 'center', justifyContent: 'center' }}>
                                <Octicons name="checklist" size={18} color="#018882" style={{ marginLeft: 5 }} />
                                <Text style={{ fontWeight: 'bold', fontSize: 18, color: '#018882', marginLeft: 5 }}>Attendence</Text>
                            </View>
                        ),
                    }}
                />
                <Tab.Screen
                    name="Calendar"
                    component={Calendar}
                    options={{
                        headerTitle: ' ',
                        headerLeft: () => (
                            <View style={{ flexDirection: 'row', marginLeft: 15, alignItems: 'center', justifyContent: 'center' }}>
                                <Octicons name="calendar" size={18} color="#018882" style={{ marginLeft: 5 }} />
                                <Text style={{ fontWeight: 'bold', fontSize: 18, color: '#018882', marginLeft: 5 }}>Calendar</Text>
                            </View>
                        ),
                    }}
                />
                <Tab.Screen
                    name="More"
                    component={More}
                    initialParams={{ logout: logOut }}
                    options={{
                        headerTitle: ' ',
                        headerLeft: () => (
                            <View style={{ flexDirection: 'row', marginLeft: 15, alignItems: 'center', justifyContent: 'center' }}>
                                <Octicons name="package" size={18} color="#018882" style={{ marginLeft: 5 }} />
                                <Text style={{ fontWeight: 'bold', fontSize: 18, color: '#018882', marginLeft: 5 }}>More</Text>
                            </View>
                        ),
                    }}
                />
            </Tab.Navigator>
        )
    }
    return (
        <AuthContext.Provider
            value={{
                activate,
                isLoggedIn,
            }}
        >
            <NavigationContainer>
                {isLoggedIn ? (
                    <Stack.Navigator>
                        <Stack.Screen
                            name='HomeScreen'
                            component={HomeTabs}
                            options={{ headerShown: false }}
                        />
                        <Stack.Screen
                            name='StudentID'
                            component={StudentIdScreen}
                            options={({ navigation }) => ({
                                title: 'Student iD',
                                headerStyle: {
                                    backgroundColor: '#018882', // Set header background color to red
                                },
                                headerTintColor: '#fff', // Set title color to white
                                headerLeft: () => (
                                    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', }} onPress={() => navigation.goBack()}>
                                        <Ionicons name="arrow-back" size={24} color="#fff" />
                                        <Text style={{ color: '#fff', marginLeft: 2, fontWeight: '500', fontSize: 16 }}>Back</Text>
                                    </TouchableOpacity>
                                ),
                            })}
                        />
                        
                        <Stack.Screen
                            name='grade'
                            component={GradeComponent}
                            // options={{ headerShown: false }}
                            options={({ navigation }) => ({
                                title: 'My Grades',
                                headerStyle: {
                                    backgroundColor: '#018882', // Set header background color to red
                                },
                                headerTintColor: '#fff', // Set title color to white
                                headerLeft: () => (
                                    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', }} onPress={() => navigation.goBack()}>
                                        <Ionicons name="arrow-back" size={24} color="#fff" />
                                        <Text style={{ color: '#fff', marginLeft: 2, fontWeight: '500', fontSize: 16 }}>Back</Text>
                                    </TouchableOpacity>
                                ),
                            })}
                        />
                        <Stack.Screen
                            name='mc'
                            component={StudentsMc}
                            // options={{ headerShown: false }}
                            options={({ navigation }) => ({
                                title: "Student's MC",
                                headerStyle: {
                                    backgroundColor: '#018882', // Set header background color to red
                                },
                                headerTintColor: '#fff', // Set title color to white
                                headerLeft: () => (
                                    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', }} onPress={() => navigation.goBack()}>
                                        <Ionicons name="arrow-back" size={24} color="#fff" />
                                        <Text style={{ color: '#fff', marginLeft: 2, fontWeight: '500', fontSize: 16 }}>Back</Text>
                                    </TouchableOpacity>
                                ),
                            })}
                        />
                        <Stack.Screen
                            name='Assignments'
                            component={Assignments}
                            // options={{ headerShown: false }}
                            options={({ navigation }) => ({
                                title: 'Student Assignments',
                                headerStyle: {
                                    backgroundColor: '#018882', // Set header background color to red
                                },
                                headerTintColor: '#fff', // Set title color to white
                                headerLeft: () => (
                                    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', }} onPress={() => navigation.goBack()}>
                                        <Ionicons name="arrow-back" size={24} color="#fff" />
                                        <Text style={{ color: '#fff', marginLeft: 2, fontWeight: '500', fontSize: 16 }}>Back</Text>
                                    </TouchableOpacity>
                                ),
                            })}
                        />



                        <Stack.Group screenOptions={{ presentation: 'modal' }}>
                            <Stack.Screen
                                name='AddNewMc'
                                component={NewMc}
                                options={({ navigation }) => ({
                                    title: "Add new",
                                    headerStyle: {
                                        backgroundColor: '#018882', // Set header background color to red
                                    },
                                    headerTintColor: '#fff', // Set title color to white
                                    headerLeft: () => (
                                        <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', }} onPress={() => navigation.goBack()}>
                                            <Ionicons name="arrow-back" size={24} color="#fff" />
                                            <Text style={{ color: '#fff', marginLeft: 2, fontWeight: '500', fontSize: 16 }}>Back</Text>
                                        </TouchableOpacity>
                                    ),
                                })}
                            />
                            <Stack.Screen
                                name='Notifications'
                                component={Notifications}
                                // options={{ headerShown: false }}
                                options={({ navigation }) => ({
                                    title: "Notifications",
                                    headerStyle: {
                                        backgroundColor: '#018882', // Set header background color to red
                                    },
                                    headerTintColor: '#fff', // Set title color to white
                                    headerLeft: () => (
                                        <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', }} onPress={() => navigation.goBack()}>
                                            <Ionicons name="arrow-back" size={24} color="#fff" />
                                            <Text style={{ color: '#fff', marginLeft: 2, fontWeight: '500', fontSize: 16 }}>Back</Text>
                                        </TouchableOpacity>
                                    ),
                                })}
                            />
                            <Stack.Screen
                                name='AttendanceModule'
                                component={AttendanceModule}
                                // options={{ headerShown: false }}
                                options={({ navigation }) => ({
                                    title: 'Absents list',
                                    headerStyle: {
                                        backgroundColor: '#018882', // Set header background color to red
                                    },
                                    headerTintColor: '#fff', // Set title color to white
                                    headerLeft: () => (
                                        <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', }} onPress={() => navigation.goBack()}>
                                            <Ionicons name="arrow-back" size={24} color="#fff" />
                                            <Text style={{ color: '#fff', marginLeft: 2, fontWeight: '500', fontSize: 16 }}>Back</Text>
                                        </TouchableOpacity>
                                    ),
                                })}
                            />
                            <Stack.Screen
                                name='Survey'
                                component={StudentsSurvey}
                                // options={{ headerShown: false }}
                                options={({ navigation }) => ({
                                    title: 'Survey',
                                    headerStyle: {
                                        backgroundColor: '#018882', // Set header background color to red
                                    },
                                    headerTintColor: '#fff', // Set title color to white
                                    headerLeft: () => (
                                        <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', }} onPress={() => navigation.goBack()}>
                                            <Ionicons name="arrow-back" size={24} color="#fff" />
                                            <Text style={{ color: '#fff', marginLeft: 2, fontWeight: '500', fontSize: 16 }}>Back</Text>
                                        </TouchableOpacity>
                                    ),
                                })}
                            />

                            <Stack.Screen
                                name='AssignmentDetails'
                                component={AssignmentDetails}
                                // options={{ headerShown: false }}
                                options={({ navigation }) => ({
                                    title: 'AssignmentDetails',
                                    headerStyle: {
                                        backgroundColor: '#018882', // Set header background color to red
                                    },
                                    headerTintColor: '#fff', // Set title color to white
                                    headerLeft: () => (
                                        <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', }} onPress={() => navigation.goBack()}>
                                            <Ionicons name="arrow-back" size={24} color="#fff" />
                                            <Text style={{ color: '#fff', marginLeft: 2, fontWeight: '500', fontSize: 16 }}>Back</Text>
                                        </TouchableOpacity>
                                    ),
                                })}
                            />
                        </Stack.Group>
                    </Stack.Navigator>
                ) : (
                    <Stack.Navigator>
                        <Stack.Screen
                            name="SignIn"
                            component={SignIn}
                            options={{ headerShown: false }}
                        />
                    </Stack.Navigator>
                )}
            </NavigationContainer>
        </AuthContext.Provider>
    );
};

export default Navigation;